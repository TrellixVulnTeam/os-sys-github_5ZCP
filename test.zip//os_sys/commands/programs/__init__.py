try:
    from . import fail
except Exception:
    pass
else:
    fail = fail

